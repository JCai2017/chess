/*Jason Cai
 *EID: jsc3234
 * Vishakh Shukla
 * EID: vys77
 */

import java.util.ArrayList;
import java.util.Scanner;

public abstract class ChessPieces {
	
	protected int x = 0;
	protected int y = 0;
	public static ChessBoard board = new ChessBoard();
	private static ArrayList<ChessPieces> white = new ArrayList<ChessPieces>();
	private static ArrayList<ChessPieces> black = new ArrayList<ChessPieces>();
	private static ArrayList<ChessPieces> whiteTaken = new ArrayList<ChessPieces>();
	private static ArrayList<ChessPieces> blackTaken = new ArrayList<ChessPieces>();
	static Scanner sc = new Scanner(System.in);
	
	private static ArrayList<ChessPieces> currentTeam = white;
	private static ArrayList<ChessPieces> opponent = black;
	
	private static boolean whiteTurn = true;
	
	public  int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public static void placePieces(){
		white.add(new WhiteKing(4,7));
		black.add(new BlackKing(4,0));
		
		white.add(new WhiteQueen(3,7));
		black.add(new BlackQueen(3,0));
		
		for(int i = 0; i< 8; i += 1){
			white.add(new WhitePawn(i,6));
			black.add(new BlackPawn(i,1));
		}
		
		for(int i = 0; i < 2; i += 1){
			white.add(new WhiteRook(i*7, 7));
			black.add(new BlackRook(i*7, 0));
		}
		
		for(int i = 0; i < 2; i += 1){
			white.add(new WhiteKnight((i*5) + 1, 7));
			black.add(new BlackKnight((i*5) + 1, 0));
		}
		
		for(int i = 0; i < 2; i += 1){
			white.add(new WhiteBishop((i*3) + 2, 7));
			black.add(new BlackBishop((i*3) + 2, 0));
		}
	}
	
	public boolean move(int xPos, int yPos){
		if(isValidMove(xPos,yPos)){
			board.positions.get(this.x).set(this.y, null);
			this.x=xPos;
			this.y=yPos;
			board.positions.get(this.x).set(this.y, this);
			return true;
		}else{
			System.out.println("Invalid Move. Choose another move.");
			return false;
		}
	}
	abstract boolean isValidMove(int xPos, int yPos);
	
	abstract javafx.scene.image.Image piece();
	
	public boolean isWhite(){
		return false;
	}
	
	public boolean causeCheck(int xPos, int yPos){
		
		int checkX = xPos + 1;
		int checkY = yPos + 1;
		while(checkX < 8 && checkY < 8){
			if(!board.posValid(checkX, checkY)){
				if(checkX == xPos + 1){
					int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof BlackPawn || opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhitePawn || opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX += 1;
			checkY += 1;
		}
		
		checkX = xPos - 1;
		checkY = yPos - 1;
		while(checkX >= 0 && checkY >= 0){
			if(!board.posValid(checkX, checkY)){
				if(checkX == xPos - 1){
					int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof BlackPawn || opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhitePawn || opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX -= 1;
			checkY -= 1;
		}
		
		checkX = xPos + 1;
		checkY = yPos - 1;
		while(checkX < 8 && checkY >= 0){
			if(!board.posValid(checkX, checkY)){
				if(checkX == xPos + 1){
					int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof BlackPawn || opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhitePawn || opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX += 1;
			checkY -= 1;
		}
		
		checkX = xPos - 1;
		checkY = yPos + 1;
		while(checkX >= 0 && checkY < 8){
			if(!board.posValid(checkX, checkY)){
				if(checkX == xPos - 1){
					int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof BlackPawn || opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhitePawn || opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackBishop){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteBishop){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX -= 1;
			checkY += 1;
		}
		
		checkX = xPos + 1;
		while(checkX < 8){
			if(!board.posValid(checkX, yPos)){
				if(checkX == xPos + 1){
					int ind = opponent.indexOf(board.positions.get(checkX).get(yPos));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if( opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(checkX).get(yPos));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX += 1;
		}
		
		checkX = xPos - 1;
		
		while(checkX >= 0){
			if(!board.posValid(checkX, yPos)){
				if(checkX == xPos - 1){
					int ind = opponent.indexOf(board.positions.get(checkX).get(yPos));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if( opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(checkX).get(yPos));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX -= 1;
		}
		
		checkY = yPos + 1;
		while(checkY < 8){
			if(!board.posValid(xPos, checkY)){
				if(yPos == yPos + 1){
					int ind = opponent.indexOf(board.positions.get(xPos).get(checkY));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if( opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(xPos).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkY += 1;
		}
		
		checkY = yPos - 1;
		while(checkY >= 0){
			if(!board.posValid(xPos, checkY)){
				if(yPos == yPos - 1){
					int ind = opponent.indexOf(board.positions.get(xPos).get(checkY));
					if(ind >=0 ){
						if(!opponent.get(ind).isWhite()){
							if( opponent.get(ind) instanceof BlackKing || opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
								return true;
							}
						}else if(opponent.get(ind).isWhite()){
							if(opponent.get(ind) instanceof WhiteKing || opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
								return true;
							}
						}
					}else{
						break;
					}
				}
				int ind = opponent.indexOf(board.positions.get(xPos).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackQueen || opponent.get(ind) instanceof BlackRook){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteQueen || opponent.get(ind) instanceof WhiteRook){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkY -= 1;
		}
		
		checkX = xPos + 2;
		checkY = yPos + 1;
		for(int i = 0; i < 2; i += 1){
			if(!board.posValid(checkX, checkY)  && (checkX < 8) &&(checkY < 8) && (checkY >= 0)){
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackKnight){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteKnight){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkY -= 2;
		}
		
		checkX = xPos - 2;
		checkY = yPos + 1;
		for(int i = 0; i < 2; i += 1){
			if(!board.posValid(checkX, checkY) && (checkX >= 0) &&(checkY < 8) && (checkY >= 0)){
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackKnight){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteKnight){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkY -= 2;
		}
		
		checkX = xPos + 1;
		checkY = yPos + 2;
		for(int i = 0; i < 2; i += 1){
			if(!board.posValid(checkX, checkY) && (checkY < 8) &&(checkX < 8) && (checkX >= 0)){
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackKnight){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteKnight){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX -= 2;
		}
		
		checkX = xPos + 1;
		checkY = yPos - 2;
		for(int i = 0; i < 2; i += 1){
			if(!board.posValid(checkX, checkY) && (checkY > 0) &&(checkX < 8) && (checkX >= 0)){
				int ind = opponent.indexOf(board.positions.get(checkX).get(checkY));
				if(ind >=0 ){
					if(!opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof BlackKnight){
							return true;
						}
					}else if(opponent.get(ind).isWhite()){
						if(opponent.get(ind) instanceof WhiteKnight){
							return true;
						}
					}
				}else{
					break;
				}
			}
			
			checkX -= 2;
		}
		
		
		return false;
	}
	
	public static boolean inWhite(ChessPieces piece){
		if(white.contains(piece)){
			return true;
		}
		
		return false;
	}
	
	public static boolean wTurn(){
		return whiteTurn;
	}
	
	public void removePiece(ChessPieces taken){
		if(taken == null){
			return;
		}
		ChessPieces toRemove = null;
		int index = -1;
		if(taken.isWhite()){
			index = white.indexOf(taken);
			if(index != -1){
				toRemove = white.remove(index);
				board.positions.get(toRemove.x).set(toRemove.y, null);
				blackTaken.add(toRemove);
			}
		}else{
			index = black.indexOf(taken);
			if(index != -1){
				toRemove = black.remove(index);
				whiteTaken.add(toRemove);
			}
		}
	}
	
	public void returnPiece(ChessPieces notValid){
		if(notValid.isWhite()){
			blackTaken.remove(notValid);
			white.add(notValid);
		}else{
			whiteTaken.remove(notValid);
			black.add(notValid);
		}
	}
	
	public static boolean turn(ChessPieces toMove, int xPos, int yPos){
		int index = currentTeam.indexOf(toMove);
		boolean moved = false;
		moved = currentTeam.get(index).move(xPos, yPos);
		if(!moved){
			return false;
		}
		if(moved){
			if(currentTeam.get(index) instanceof WhitePawn){
				if(currentTeam.get(index).y == 0){
					while(true){
						System.out.println("Choose a piece type to promote to: ");
						String s = sc.nextLine();
						if(!s.equals("Queen") || !s.equals("Rook") || !s.equals("Knight") || !s.equals("Bishop")){
							System.out.println("Invalid Choice Choose Again");
						}else{
							String piece = "White";
							piece.concat(s);
							ChessPieces promoted = ((WhitePawn) (currentTeam.get(index))).promote(piece);
							if(promoted == null){
								System.out.println("Piece not Found");
							}else{
								currentTeam.remove(index);
								currentTeam.add(promoted);
								board.positions.get(promoted.x).set(promoted.y, promoted);
								break;
							}
						}
					}
				}
			}else if(currentTeam.get(index) instanceof BlackPawn){
				if(currentTeam.get(index).y == 7){
					while(true){
						System.out.println("Choose a piece type to promote to: ");
						String s = sc.nextLine();
						if(!s.equals("Queen") || !s.equals("Rook") || !s.equals("Knight") || !s.equals("Bishop")){
							System.out.println("Invalid Choice Choose Again");
						}else{
							String piece = "Black";
							piece.concat(s);
							ChessPieces promoted = ((BlackPawn) (currentTeam.get(index))).promote(piece);
							if(promoted == null){
								System.out.println("Piece not Found");
							}else{
								currentTeam.remove(index);
								currentTeam.add(promoted);
								board.positions.get(promoted.x).set(promoted.y, promoted);
								break;
							}
						}
					}
				}
			}
		}
		
		whiteTurn = !whiteTurn;
		if(whiteTurn){
			currentTeam = white;
			opponent = black;
		}else{
			currentTeam = black;
			opponent = white;
		}
		
		return true;
	}
	
	public static void displayBoard(){
		javaFx.updateCanvas(white, black);
		javaFx.updateTaken(whiteTaken, blackTaken);
	}

}
